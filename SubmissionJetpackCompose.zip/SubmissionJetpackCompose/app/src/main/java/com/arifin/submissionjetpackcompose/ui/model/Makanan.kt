package com.arifin.submissionjetpackcompose.ui.model

data class Makanan(
    val id: Long,
    val food_name: String,
    val description: String,
    val food_country: String,
    val food_picture: Int
)