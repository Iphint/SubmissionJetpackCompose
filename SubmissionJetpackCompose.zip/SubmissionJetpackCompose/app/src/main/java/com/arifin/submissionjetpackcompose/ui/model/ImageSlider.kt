package com.arifin.submissionjetpackcompose.ui.model

import com.arifin.submissionjetpackcompose.R

object ImageSlider {
    val images = listOf(
        R.drawable.food_banner,
        R.drawable.bakso,
        R.drawable.sushi,
        R.drawable.dimsum,
    )
}